@echo off
rem Double-click to install or update Gentle Shell.
rem It runs the bundled bootstrap, which opens the installation wizard in your browser.
call "%~dp0installer\scripts\bootstrap.cmd"
echo.
if errorlevel 1 (
  echo The installer stopped. Read the messages above, then close this window.
) else (
  echo You can close this window.
)
pause
